
# CodeSafetyBomer V1.0
Доброго времени суток!

Функционал бомбера:
1. Конечно же четкий, многопоточный спам
2. Использование ваших прокси
3. Несколько способов спама
4. А самое главное - спам нескольких номеров одновренно

# Установка для Termux:

git clone https://github.com/AdolfGitHuber/CodeSafetyBomber

cd CodeSafetyBomber

pip install -r requierment.txt

python main.py

# End
